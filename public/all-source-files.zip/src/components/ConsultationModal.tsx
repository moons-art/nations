import React from 'react';

interface ConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
  preset?: {
    type?: 'demo' | 'free_under_100' | 'consultation';
    product?: string;
  };
  onSubmitSuccess?: (data: any) => void;
}

export const ConsultationModal: React.FC<ConsultationModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const handleVoteAppClick = () => {
    window.open('https://vote.thenations.kr/', '_blank', 'noopener,noreferrer');
  };

  const handleScoreAppClick = () => {
    window.open('https://studio.thenations.kr/', '_blank', 'noopener,noreferrer');
  };

  const handleBibleAppClick = () => {
    window.open('https://bible.thenations.kr/', '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      {/* Claude-like warm dark backdrop */}
      <div
        className="fixed inset-0 bg-[#1c1917]/70 backdrop-blur-[4px] transition-opacity"
        onClick={onClose}
      />

      {/* Claude Aesthetic Container: Warm Sand/Cream Tone (#FAF9F5), Crisp Border (#E7E3DC), Terracotta Accents */}
      <div className="relative w-full max-w-lg bg-[#FAF8F5] text-[#2C2621] rounded-3xl shadow-[0_25px_60px_-15px_rgba(28,25,23,0.35)] z-10 max-h-[92vh] flex flex-col overflow-hidden border border-[#E7E2D9] animate-in zoom-in-95 duration-200">
        
        {/* Modal Header */}
        <div className="px-5 py-4 sm:px-6 sm:py-5 border-b border-[#ECE7DF] bg-[#F5F1EA]/85 backdrop-blur-sm flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#D97757]/15 text-[#C45E3B] flex items-center justify-center border border-[#D97757]/20">
              <span className="material-symbols-outlined text-[20px]">apps</span>
            </div>
            <div>
              <h3 className="text-[17px] sm:text-[18px] font-bold text-[#2C2621] tracking-tight">
                네이션스 앱 사용하기
              </h3>
              <p className="text-[12px] text-[#786E64] font-medium">
                더네이션스의 스마트 목회 & 사역 솔루션
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-[#8C8276] hover:text-[#2C2621] hover:bg-[#EBE4DA] transition-colors cursor-pointer"
            aria-label="닫기"
          >
            <span className="material-symbols-outlined text-[20px]">close</span>
          </button>
        </div>

        {/* Modal Content Body: Claude Card Layout */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3.5">
          
          {/* Card 1: 교회투표 (100명 미만 무료 지원 명시) */}
          <div className="p-4 sm:p-5 bg-white rounded-2xl border border-[#E8E2D8] shadow-[0_2px_8px_rgba(44,38,33,0.04)] hover:border-[#D97757]/40 transition-all flex flex-col gap-3 group">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#D97757]" />
                <h4 className="text-[15.5px] sm:text-[16.5px] font-bold text-[#2C2621] tracking-tight">
                  네이션스 교회투표
                </h4>
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-[#FAF0EB] text-[#C45E3B] border border-[#D97757]/25 shrink-0">
                100명 미만 무료
              </span>
            </div>

            {/* Support Message Box */}
            <div className="p-3 bg-[#FAF8F5] rounded-xl border border-[#ECE7DE] text-[13px] text-[#4A423A] leading-relaxed">
              <span className="font-bold text-[#C45E3B] block mb-0.5">100명 미만</span>
              개척교회 및 미자립 교회의 사역을 위해 기본 이용료를 무료로 지원합니다.
            </div>

            {/* App Launch Button */}
            <button
              type="button"
              onClick={handleVoteAppClick}
              className="w-full py-3 px-4 bg-[#C45E3B] hover:bg-[#b05232] active:scale-[0.98] text-white rounded-xl text-[14px] font-bold flex items-center justify-center gap-1.5 shadow-[0_4px_12px_rgba(196,94,59,0.25)] transition-all cursor-pointer group"
            >
              <span>*네이션스 교회투표 앱 들어가기</span>
              <span className="material-symbols-outlined text-[17px] group-hover:translate-x-0.5 transition-transform">
                arrow_forward
              </span>
            </button>
          </div>

          {/* Card 2: 네이션스 스튜디오 */}
          <div className="p-4 sm:p-5 bg-white rounded-2xl border border-[#E8E2D8] shadow-[0_2px_8px_rgba(44,38,33,0.04)] hover:border-[#D97757]/40 transition-all flex flex-col gap-3 group">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#786E64]" />
                <h4 className="text-[15.5px] sm:text-[16.5px] font-bold text-[#2C2621] tracking-tight">
                  네이션스 스튜디오
                </h4>
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-[#F5F1EA] text-[#786E64] border border-[#E4DDD3] shrink-0">
                찬양 & 악보 솔루션
              </span>
            </div>

            <p className="text-[13px] text-[#6A6157] leading-relaxed">
              찬양팀 콘티와 스마트 디지털 악보 뷰어, 앙상블 합주 동기화까지 한 번에 관리하세요.
            </p>

            {/* App Launch Button */}
            <button
              type="button"
              onClick={handleScoreAppClick}
              className="w-full py-3 px-4 bg-[#4A423A] hover:bg-[#3B342E] active:scale-[0.98] text-[#FAF8F5] rounded-xl text-[14px] font-bold flex items-center justify-center gap-1.5 shadow-[0_2px_8px_rgba(74,66,58,0.2)] transition-all cursor-pointer group"
            >
              <span>네이션스 스튜디오 앱 들어가기</span>
              <span className="material-symbols-outlined text-[17px] group-hover:translate-x-0.5 transition-transform">
                arrow_forward
              </span>
            </button>
          </div>

          {/* Card 3: 네이션스 성경 */}
          <div className="p-4 sm:p-5 bg-white rounded-2xl border border-[#E8E2D8] shadow-[0_2px_8px_rgba(44,38,33,0.04)] hover:border-[#D97757]/40 transition-all flex flex-col gap-3 group">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#786E64]" />
                <h4 className="text-[15.5px] sm:text-[16.5px] font-bold text-[#2C2621] tracking-tight">
                  네이션스 성경
                </h4>
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-[#F5F1EA] text-[#786E64] border border-[#E4DDD3] shrink-0">
                설교 & 말씀 연구
              </span>
            </div>

            <p className="text-[13px] text-[#6A6157] leading-relaxed">
              원어 분해, 다역본 대조, 개인 주석 노트가 유기적으로 연결된 올인원 설교 연구 도구입니다.
            </p>

            {/* App Launch Button */}
            <button
              type="button"
              onClick={handleBibleAppClick}
              className="w-full py-3 px-4 bg-[#4A423A] hover:bg-[#3B342E] active:scale-[0.98] text-[#FAF8F5] rounded-xl text-[14px] font-bold flex items-center justify-center gap-1.5 shadow-[0_2px_8px_rgba(74,66,58,0.2)] transition-all cursor-pointer group"
            >
              <span>네이션스 성경 앱 들어가기</span>
              <span className="material-symbols-outlined text-[17px] group-hover:translate-x-0.5 transition-transform">
                arrow_forward
              </span>
            </button>
          </div>

          {/* Footer Note & Kakao Inquiries */}
          <div className="pt-2 flex flex-col gap-2">
            <div className="p-3 bg-[#F5F1EA] rounded-xl border border-[#ECE7DF] text-[12px] text-[#786E64] flex items-center justify-between">
              <span>* 네이션스 회원 계정으로 모든 앱이 연동됩니다.</span>
            </div>

            <a
              href="http://pf.kakao.com/_cxjBxaX/chat"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 bg-[#FEE500] hover:brightness-95 active:scale-[0.98] text-[#371D1E] rounded-xl text-[13px] font-bold shadow-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
            >
              <span className="material-symbols-outlined text-[17px]">forum</span>
              <span>카카오톡 채널 실시간 문의</span>
              <span className="material-symbols-outlined text-[14px]">open_in_new</span>
            </a>
          </div>

        </div>
      </div>
    </div>
  );
};
