import React from 'react';
import { NATIONS_LOGO_URL } from '../data/products';

interface NavigationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activePage: 'vote' | 'score' | 'bible';
  onSelectPage: (page: 'vote' | 'score' | 'bible') => void;
  onOpenKakao: () => void;
  onOpenDemoModal: (preset?: { type?: 'demo' | 'free_under_100'; product?: string }) => void;
  onOpenTerms: () => void;
  onOpenPrivacy: () => void;
}

export const NavigationDrawer: React.FC<NavigationDrawerProps> = ({
  isOpen,
  onClose,
  activePage,
  onSelectPage,
  onOpenKakao,
  onOpenDemoModal,
  onOpenTerms,
  onOpenPrivacy,
}) => {
  if (!isOpen) return null;

  const handleSelectTab = (page: 'vote' | 'score' | 'bible') => {
    onSelectPage(page);
    onClose();
  };

  const handleScrollTo = (elementId: string) => {
    onClose();
    setTimeout(() => {
      const el = document.getElementById(elementId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 200);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      {/* Dark Outer Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-[4px] transition-opacity animate-in fade-in duration-200"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer Panel - Translucent Black Background (bg-black/85 with backdrop-blur-xl) with Crisp White Typography */}
      <div className="relative w-full max-w-[320px] sm:max-w-[340px] bg-[#0c0d0e]/85 backdrop-blur-xl text-white h-full shadow-[0_0_60px_rgba(0,0,0,0.85)] z-10 flex flex-col border-l border-white/10 animate-in slide-in-from-right duration-200 select-none">
        
        {/* Header: White Logo & Sleek Sidebar Collapse Icon */}
        <div className="px-5 py-5 flex items-center justify-between border-b border-white/10 bg-white/[0.02]">
          <div className="flex items-center gap-2">
            <img
              alt="NATIONS 로고"
              className="h-5 sm:h-6 w-auto object-contain drop-shadow-md"
              src={NATIONS_LOGO_URL}
            />
          </div>
          <button
            onClick={onClose}
            aria-label="사이드바 닫기"
            className="w-8 h-8 rounded-lg flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 active:scale-95 transition-all cursor-pointer"
          >
            <span className="material-symbols-outlined text-[22px]">dock_to_right</span>
          </button>
        </div>

        {/* Content Body: Scrollable Dark Minimalist Layout */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 text-[13.5px]">
          
          {/* Section 1: 솔루션 페이지 바로가기 */}
          <div>
            <div className="flex items-center justify-between mb-1.5 px-2">
              <span className="text-[11px] font-bold text-white/40 tracking-wider uppercase">
                솔루션 페이지 바로가기
              </span>
            </div>

            <div className="space-y-1">
              {/* 1. 네이션스 Vote */}
              <button
                type="button"
                onClick={() => handleSelectTab('vote')}
                className={`w-full px-3 py-2.5 rounded-xl flex items-center justify-between transition-all cursor-pointer ${
                  activePage === 'vote'
                    ? 'bg-white/15 text-white font-bold border border-white/20 shadow-xs'
                    : 'text-white/80 hover:bg-white/10 hover:text-white border border-transparent'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className={`material-symbols-outlined text-[19px] ${
                    activePage === 'vote' ? 'text-[#85f8c4]' : 'text-white/60'
                  }`}>
                    how_to_vote
                  </span>
                  <span className="text-[13.5px]">네이션스 Vote</span>
                </div>
                {activePage === 'vote' ? (
                  <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-[#006948] text-[#85f8c4] border border-[#006948]/50">
                    현재
                  </span>
                ) : (
                  <span className="material-symbols-outlined text-[16px] text-white/30">
                    chevron_right
                  </span>
                )}
              </button>

              {/* 2. 네이션스 Studio */}
              <button
                type="button"
                onClick={() => handleSelectTab('score')}
                className={`w-full px-3 py-2.5 rounded-xl flex items-center justify-between transition-all cursor-pointer ${
                  activePage === 'score'
                    ? 'bg-white/15 text-white font-bold border border-white/20 shadow-xs'
                    : 'text-white/80 hover:bg-white/10 hover:text-white border border-transparent'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className={`material-symbols-outlined text-[19px] ${
                    activePage === 'score' ? 'text-[#85f8c4]' : 'text-white/60'
                  }`}>
                    queue_music
                  </span>
                  <span className="text-[13.5px]">네이션스 Studio</span>
                </div>
                {activePage === 'score' ? (
                  <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-[#006948] text-[#85f8c4] border border-[#006948]/50">
                    현재
                  </span>
                ) : (
                  <span className="material-symbols-outlined text-[16px] text-white/30">
                    chevron_right
                  </span>
                )}
              </button>

              {/* 3. 네이션스 Bible */}
              <button
                type="button"
                onClick={() => handleSelectTab('bible')}
                className={`w-full px-3 py-2.5 rounded-xl flex items-center justify-between transition-all cursor-pointer ${
                  activePage === 'bible'
                    ? 'bg-white/15 text-white font-bold border border-white/20 shadow-xs'
                    : 'text-white/80 hover:bg-white/10 hover:text-white border border-transparent'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className={`material-symbols-outlined text-[19px] ${
                    activePage === 'bible' ? 'text-[#85f8c4]' : 'text-white/60'
                  }`}>
                    menu_book
                  </span>
                  <span className="text-[13.5px]">네이션스 Bible</span>
                </div>
                {activePage === 'bible' ? (
                  <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-[#006948] text-[#85f8c4] border border-[#006948]/50">
                    현재
                  </span>
                ) : (
                  <span className="material-symbols-outlined text-[16px] text-white/30">
                    chevron_right
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Section 2: 100명 미만 미자립/개척교회 무료 지원 카드 (반투명 다크 글래스 카드) */}
          <div className="p-3.5 bg-white/[0.06] rounded-2xl border border-white/10 shadow-[0_4px_16px_rgba(0,0,0,0.3)] space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-[#85f8c4] tracking-wider">
                네이션스 특별 지원
              </span>
              <span className="px-2 py-0.5 rounded text-[10.5px] font-bold bg-[#006948]/60 text-[#85f8c4] border border-[#85f8c4]/30">
                무료
              </span>
            </div>
            <p className="text-[12.5px] text-white/90 font-medium leading-snug">
              100명 미만 개척교회 및 미자립 교회를 위한 무료 지원
            </p>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenDemoModal({ type: 'free_under_100' });
              }}
              className="w-full py-2 bg-[#006948] hover:bg-[#00855d] active:scale-[0.98] text-white rounded-xl text-[12.5px] font-bold flex items-center justify-center gap-1.5 shadow-[0_2px_10px_rgba(0,105,72,0.3)] transition-all cursor-pointer"
            >
              <span className="material-symbols-outlined text-[16px] text-[#85f8c4]">apps</span>
              <span>앱 들어가기</span>
            </button>
          </div>

          {/* Section 3: Nations 안내 */}
          <div className="border-t border-white/10 pt-3">
            <div className="px-2 mb-1.5">
              <span className="text-[11px] font-bold text-white/40 tracking-wider uppercase">
                Nations 안내
              </span>
            </div>

            <div className="space-y-0.5">
              <button
                type="button"
                onClick={() => handleScrollTo('service-guide')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-between text-white/80 hover:bg-white/10 hover:text-white transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-[19px] text-[#85f8c4]">church</span>
                  <span className="font-medium text-[13.5px]">서비스 안내</span>
                </div>
                <span className="material-symbols-outlined text-[16px] text-white/30">chevron_right</span>
              </button>

              <button
                type="button"
                onClick={() => handleScrollTo('ecosystem')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-between text-white/80 hover:bg-white/10 hover:text-white transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-[19px] text-[#85f8c4]">hub</span>
                  <span className="font-medium text-[13.5px]">스마트 생태계</span>
                </div>
                <span className="material-symbols-outlined text-[16px] text-white/30">chevron_right</span>
              </button>

              <button
                type="button"
                onClick={() => handleScrollTo('core-values')}
                className="w-full px-3 py-2 rounded-xl flex items-center justify-between text-white/80 hover:bg-white/10 hover:text-white transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <span className="material-symbols-outlined text-[19px] text-[#85f8c4]">verified</span>
                  <span className="font-medium text-[13.5px]">네이션스 가치</span>
                </div>
                <span className="material-symbols-outlined text-[16px] text-white/30">chevron_right</span>
              </button>
            </div>
          </div>

          {/* Section 4: 네이션스 앱 사용하기 버튼 */}
          <div className="border-t border-white/10 pt-3">
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenDemoModal({ type: 'free_under_100' });
              }}
              className="w-full px-3 py-2.5 rounded-xl flex items-center justify-between bg-white/[0.04] hover:bg-white/10 text-white/90 hover:text-white border border-white/10 transition-all cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <span className="material-symbols-outlined text-[19px] text-[#85f8c4]">apps</span>
                <span className="font-medium text-[13.5px]">네이션스 앱 사용하기</span>
              </div>
              <span className="material-symbols-outlined text-[16px] text-white/50">arrow_forward</span>
            </button>
          </div>

        </div>

        {/* Section 5: 하단 카카오 1:1 상담 및 이용약관 / 사업자 정보 */}
        <div className="p-4 border-t border-white/10 bg-black/40 space-y-2.5">
          {/* Kakao 1:1 Inquiries pill button */}
          <div className="flex items-center justify-between text-[12px] text-white/60">
            <span className="font-medium">네이션스 솔루션</span>
            <button
              type="button"
              onClick={() => {
                onClose();
                onOpenKakao();
              }}
              className="px-3 py-1.5 rounded-full bg-[#FEE500] hover:bg-[#ffe812] active:scale-[0.98] text-[#371D1E] font-bold flex items-center gap-1 shadow-[0_2px_10px_rgba(254,229,0,0.25)] transition-all cursor-pointer text-[12px]"
            >
              <span className="material-symbols-outlined text-[15px]">chat</span>
              <span>1:1 문의</span>
            </button>
          </div>

          {/* Legal Links */}
          <div className="flex items-center justify-start gap-2 text-[11px] text-white/40 pt-1">
            <button type="button" onClick={onOpenTerms} className="hover:text-white/70 hover:underline cursor-pointer">
              이용약관
            </button>
            <span>•</span>
            <button type="button" onClick={onOpenPrivacy} className="hover:text-white/70 hover:underline cursor-pointer">
              개인정보처리방침
            </button>
            <span>•</span>
            <button
              type="button"
              onClick={() => alert('더네이션스 솔루션\n대표: 유문식\n사업자등록번호: 712-14-02380')}
              className="hover:text-white/70 hover:underline cursor-pointer"
            >
              사업자정보
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
